"""
  100  git init
  101  git clone git@github.com:Nickolay-A/DS3onl.git
  102  git log --all --graph --oneline --decorate
  103  git status
  104  git add .
  105  git push
  106  git commit -m "commit"
  107  git push
  108  git status
  109  git add .
  110  git status
  111  git log --all --graph --oneline --decorate
  112  history
  113  git init
  114  git remote add git_hub git@github.com:Nickolay-A/GitHub_repo.git
  115  git push
  116  git status
  117  git commit - m "1"
  118  git add .
  119  git commit -m "1"
  120  git push
  121  git status
"""

https://github.com/Nickolay-A/GitHub_repo

https://gitlab.com/Nickolay-A/GitLab_repo